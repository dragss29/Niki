<?php include __DIR__ . '/../includes/header.php'; ?>

<main>
  <section class="error-container">
    <h1>404</h1>
    <p>Page not found</p>
    <a href="/" class="button">Return Home</a>
  </section>
</main>

<?php include __DIR__ . '/../includes/footer.php'; ?>