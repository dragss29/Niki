<?php
$pageTitle = 'Accueil';
include '../includes/header.php';
?>

<h2 class="text-2xl font-bold mb-4">Bienvenue sur la page d'accueil</h2>
<p class="mb-4">Voici le contenu principal de la page d'accueil.</p>
<!-- Autres contenus de la page -->

<?php
include '../includes/footer.php';
?>