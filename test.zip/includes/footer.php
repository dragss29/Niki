</main>
<footer class="bg-gray-800 text-white p-4 mt-8">
    <p class="text-center">&copy; <?php echo date('Y'); ?> Niki App. All right reserved.</p>
</footer>
</body>
</html>
